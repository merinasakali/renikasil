$i = 1160
do {
    Write-Host $i
    echo ====Mr.TakurSing====
    sleep 1
    date
    sleep 1
    echo ===================
    sleep 1
    $i--
} while ($i -gt 0)